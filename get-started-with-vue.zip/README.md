# hello-world

This is a companion repo for [Getting Started with Vue](https://medium.com/@njwest/getting-started-with-vuejs-for-web-and-native-285dc64f0f0d), a beginner's guide to VueJS published on Medium.

## Project setup

```
npm install

or

yarn install
```

### Compiles and hot-reloads for development
```
npm run serve

or

yarn run serve
```

### Compiles and minifies for production
```
npm run build

or

yarn run build
```

### Lints and fixes files
```
npm run lint

or

yarn run lint
```
